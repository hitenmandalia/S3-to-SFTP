import os
import datetime
import base64
import json
import cryptography
import tempfile
import paramiko
import pysftp
import boto3
from botocore.exceptions import ClientError


def upload(e, c):
  bucket = e['Records'][0]['s3']['bucket']['name']
  file = e['Records'][0]['s3']['object']['key']
  print('New item uploaded: s3://'  + bucket + '/' + file)


  if file.startswith('success/') or file.startswith('failure/'):
    print('File is in the /success or /failure folders hence ignoring')


  elif not file.startswith('uploads/'):
    print('File is not in uploads, success or failure folders (which are the only accepted locations) hence ignoring')


  elif not file.endswith('.csv'):
    print('File is correctly in uploads folder but is not a CSV file type hence ignoring')

  elif file.endswith('.csv'):
    print('File is in uploads folder and is a CSV - proceeding to upload to SFTP')
    smClient = boto3.client('secretsmanager')

    try:
      print('Attempting to retrieve secret details for SFTP')
      secret = json.loads(smClient.get_secret_value(SecretId=os.environ['SFTP_SECMAN_KEY'])['SecretString'])
      sftpEndpoint = secret['endpoint']
      sftpUsername = secret['username']
      sftpPemBas64Encoded = secret['pem']
      sftpPem = base64.b64decode(sftpPemBas64Encoded).decode('ascii')
      
      print('Details for SFTP Server: ' + sftpEndpoint + ' retrieved')

    except ClientError as e:
      processfile(False, bucket, file, 'Could not get secret details for SFTP: ' + e.response['Error']['Code'])

    else:
      try:
        pemFile = tempfile.NamedTemporaryFile(mode='w+', delete=False)
        csvFile = tempfile.NamedTemporaryFile(mode='w+', delete=False)
      
        pemFile.write(sftpPem)
        pemFile.close()
      
        s3Resource = boto3.resource('s3')
        response = s3Resource.Object(bucket, file).get()
        csvFileContent = response['Body'].read()
        csvFile.write(csvFileContent.decode('utf-8'))
        csvFile.close()

        with pysftp.Connection(sftpEndpoint, sftpUsername, private_key=pemFile.name) as sftp:
          print('Attempting to upload to SFTP...')
          sftp.put(csvFile.name, file.replace('uploads/',''))
          processfile(True, bucket, file, 'Successfully uploaded to SFTP')

      except:
        processfile(False, bucket, file, 'Could not upload file to the SFTP Server')

      # always try to remove the files!
      os.unlink(pemFile.name)
      os.unlink(csvFile.name)

def processfile(success, bucket, sourceFilePath, text):
  print(text)
  
  today = datetime.datetime.now()
  s3Resource = boto3.resource('s3')
  destinationFilePath = ('success' if success else 'failure') + '/' + today.strftime('%Y/%m/%d/%H-%M-%S/') + sourceFilePath.replace('uploads/','')

  print('Copying file: s3://' + bucket + '/' + sourceFilePath + '  --->  s3://' + bucket + '/' + destinationFilePath)
  s3Resource.meta.client.copy({'Bucket': bucket, 'Key': sourceFilePath}, bucket, destinationFilePath)
    
  print('Deleting original file: s3://' + bucket + '/' + sourceFilePath)
  s3Resource.meta.client.delete_objects(Bucket=bucket, Delete={'Objects': [{'Key':sourceFilePath}]})

  explanationFilePath = destinationFilePath + '.txt'
  text = today.strftime('%Y/%m/%d %H:%M:%S - ') + text
  print('Writing text explanation file: s3://' + bucket + '/' + explanationFilePath)
  s3Resource.Object(bucket, explanationFilePath).put(Body=text)

  subject = ('SUCCESS: ' if success else 'ERROR: ') + os.environ['SNS_SUBJECT']
  topic = ('SUCCESS_SNS_TOPIC' if success else 'ERROR_SNS_TOPIC')
  
  print('Sending SNS to: ' + topic)
  client = boto3.client('sns')
  client.publish(TopicArn=os.environ[topic], Message=text, Subject=subject, MessageStructure='string')
